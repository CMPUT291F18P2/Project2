Member 1:  Name: John Chmilar  ccid: jechmila
Member 2:  Name: William Wong  ccid:  wwong1
Member 3:  Name: Javin Wong  ccid: jtwong

No collaborators

Resources used:
in filecreator.py:
	https://stackoverflow.com/questions/21023901/how-to-split-at-all-special-characters-with-re-split
	https://stackoverflow.com/questions/1059559/split-strings-with-multiple-delimiters